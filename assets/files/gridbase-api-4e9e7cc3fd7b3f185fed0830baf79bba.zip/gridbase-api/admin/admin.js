var app = new Vue({
  el: "#gridbase-admin",
  data: {
    settings: {
      apiKey: "",
      logoUrl: "",
    },
    integrations: [],
    isLoading: false,
    errors: [],
    successMessage: "",
  },
  created() {
    // Load initial settings
    this.loadSettings();
    // Load integrations
    this.loadIntegrations();
  },
  methods: {
    loadSettings() {
      this.settings.apiKey = gridbaseAdmin.apiKey || "";
      this.settings.logoUrl = gridbaseAdmin.logoUrl || "";
    },
    loadIntegrations() {
      this.isLoading = true;
      fetch(gridbaseAdmin.ajaxUrl + "?action=get_user_integrations_action")
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            this.integrations = JSON.parse(data.data);
          }
          this.isLoading = false;
        })
        .catch((error) => console.error("Error:", error));
    },
    saveSettings() {
      this.isLoading = true;
      this.errors = [];
      this.successMessage = "";

      const formData = new FormData();
      formData.append("action", "save_gridbase_settings");
      formData.append("nonce", gridbaseAdmin.nonce);
      formData.append("apiKey", this.settings.apiKey);
      formData.append("logoUrl", this.settings.logoUrl);

      fetch(gridbaseAdmin.ajaxUrl, {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            this.successMessage = "Settings saved successfully!";
          } else {
            this.errors.push(data.message || "Failed to save settings");
          }
        })
        .catch((error) => {
          this.errors.push("An error occurred while saving");
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
  },
});
