<?php

// Enqueue shared scripts and styles
function enqueue_shared_scripts() {
    // Enqueue Vue.js - make sure this loads first
    wp_enqueue_script('vue', 'https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js', array(), null, true);

    // Enqueue vue helpers (make sure this depends on Vue.js)
    wp_enqueue_script('vue-helpers', plugin_dir_url(__FILE__) . '../js/vue.helpers.js', array('vue'), null, true);

    // Bootstrap CSS and JS
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), null);
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js', array('jquery'), null, true);

    // wp_enqueue_script('charts-js', 'https://cdn.jsdelivr.net/npm/chart.js', array('jquery'), null, true);   
    // Common JS file
    wp_enqueue_script('common-js', plugin_dir_url(__FILE__) . '../js/common.types.js', array('jquery', 'vue'), null, true);

    // Enqueue common CSS for both plugins
    wp_enqueue_style('common-css', plugin_dir_url(__FILE__) . '../css/common.css', array(), null);
}

add_action('wp_enqueue_scripts', 'enqueue_shared_scripts');

// Seller Net Sheet Shortcode
function seller_net_sheet_short_code() {
    // Seller Net Sheet specific scripts and styles
    wp_enqueue_script('seller-net-sheet-types-js', plugin_dir_url(__FILE__) . '../modules/seller-net-sheet/seller-net-sheet.types.js', array('jquery', 'vue'), null, true);
    wp_enqueue_script('seller-net-sheet-js', plugin_dir_url(__FILE__) . '../modules/seller-net-sheet/seller-net-sheet.js', array('jquery', 'vue','vue-helpers'), null, true);
    wp_enqueue_style('seller-net-sheet-css', plugin_dir_url(__FILE__) . '../modules/seller-net-sheet/seller-net-sheet.css', array(), null);

    wp_localize_script('seller-net-sheet-js', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));

    // Render Seller Net Sheet HTML
    ob_start();
    $template_path = plugin_dir_path(__FILE__) . '../modules/seller-net-sheet/seller-net-sheet.html'; 
    if (file_exists($template_path)) {
        $template_content = file_get_contents($template_path);
        $template_content = str_replace('{admin_ajax_url}', esc_url(admin_url('admin-ajax.php')), $template_content);
        echo $template_content;
    } else {
        echo 'Template not found.';
    }

    return ob_get_clean();
}
add_shortcode('gridbase_seller_netsheet', 'seller_net_sheet_short_code');

// Buyer Cost Estimate Shortcode
function buyer_cost_estimate_short_code() {
    // Buyer Cost Estimate specific scripts and styles
    wp_enqueue_script('buyer-cost-estimate-types-js', plugin_dir_url(__FILE__) . '../modules/buyer-cost-estimate/buyer-cost-estimate.types.js', array('jquery', 'vue'), null, true);
    wp_enqueue_script('buyer-cost-estimate-js', plugin_dir_url(__FILE__) . '../modules/buyer-cost-estimate/buyer-cost-estimate.js', array('jquery', 'vue','vue-helpers'), null, true);
    wp_localize_script('buyer-cost-estimate-js', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));

    wp_enqueue_style('buyer-cost-estimate-css', plugin_dir_url(__FILE__) . '../modules/buyer-cost-estimate/buyer-cost-estimate.css', array(), null);

    // Render Buyer Cost Estimate HTML
    ob_start();
    $template_path = plugin_dir_path(__FILE__) . '../modules/buyer-cost-estimate/buyer-cost-estimate.html'; 
    if (file_exists($template_path)) {
        $template_content = file_get_contents($template_path);
        $template_content = str_replace('{admin_ajax_url}', esc_url(admin_url('admin-ajax.php')), $template_content);
        echo $template_content;
    } else {
        echo 'Template not found.';
    }

    return ob_get_clean();
}
add_shortcode('gridbase_buyer_cost_estimate', 'buyer_cost_estimate_short_code');



