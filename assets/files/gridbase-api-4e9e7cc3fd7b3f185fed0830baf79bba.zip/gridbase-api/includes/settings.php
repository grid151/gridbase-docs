<?php

function save_gridbase_settings() {
    check_ajax_referer('gridbase_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Unauthorized access'));
        return;
    }
    
    $api_key = sanitize_text_field($_POST['apiKey']);
    $logo_url = esc_url_raw($_POST['logoUrl']);
    
    update_option('gridbase_api_key', $api_key);
    update_option('gridbase_partner_logo', $logo_url);
    
        wp_send_json_success(array(
            'message' => 'Settings updated successfully',
            'apiKey' => $api_key,
            'logoUrl' => $logo_url
        ));
    
}
add_action('wp_ajax_save_gridbase_settings', 'save_gridbase_settings');