<?php

function get_partner_logo() {
    $logo_url = get_option('gridbase_partner_logo');
    wp_send_json_success(array('logoUrl' => esc_url($logo_url)));
}
add_action('wp_ajax_get_partner_logo_action', 'get_partner_logo');
add_action('wp_ajax_nopriv_get_partner_logo_action', 'get_partner_logo');

function get_user_integrations() {

    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', 401); 
    }

    $endpoint_url = GRIDBASE_API_ENDPOINT . "/v1/orders/wordpress/integrations";

    $args = array(
        'method'      => 'GET',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_get($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        // Decode the response body to process integrations
        $integrations = json_decode(wp_remote_retrieve_body($response), true);

        if (is_array($integrations)) {
            // Save the processed integrations to WordPress options
            update_option('gridbase_user_integrations', $integrations);
        }

        // Return the original unmodified response
        wp_send_json_success(wp_remote_retrieve_body($response));
    }

    wp_die();
}
add_action('wp_ajax_get_user_integrations_action', 'get_user_integrations');
add_action('wp_ajax_nopriv_get_user_integrations_action', 'get_user_integrations');

function get_report() {
    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $endpoint_url = GRIDBASE_API_ENDPOINT . "/v1/core/reports/generate";
    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);

    $args = array(
        'method'      => 'POST',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'body'        => json_encode($data),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_post($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        $body = wp_remote_retrieve_body($response);
        // Send the URL as a plain string response
        wp_send_json_success(array('url' => $body));
    }

    wp_die();
}
add_action('wp_ajax_get_report_action', 'get_report');
add_action('wp_ajax_nopriv_get_report_action', 'get_report');