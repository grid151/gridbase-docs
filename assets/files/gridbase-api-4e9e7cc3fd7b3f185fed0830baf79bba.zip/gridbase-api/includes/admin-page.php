<?php

function gridbase_api_add_admin_menu() {
    add_menu_page(
        'GridBase API Settings', // Page title
        'GridBase API',          // Menu title
        'manage_options',        // Capability required
        'gridbase_api',         // Menu slug
        'gridbase_api_settings_page', // Function to display the page
        'dashicons-admin-settings', // Icon
        30                      // Position in menu
    );
}
add_action('admin_menu', 'gridbase_api_add_admin_menu');

function gridbase_api_settings_page() {
    include(plugin_dir_path(__FILE__) . '../admin/admin.html');
}

function gridbase_enqueue_admin_assets($hook) {
    if ('toplevel_page_gridbase_api' !== $hook) {
        return;
    }

    wp_enqueue_script(
        'vue-js',
        'https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js',
        array(),
        '2.6.14',
        true
    );

    wp_enqueue_style(
        'gridbase-admin-style',
        plugin_dir_url(__FILE__) . '../css/gridbase-api-settings.css',
        array(),
        '1.0.0'
    );

    wp_enqueue_script(
        'gridbase-admin-js',
        plugin_dir_url(__FILE__) . '../admin/admin.js',
        array('vue-js', 'jquery'),
        '1.0.0',
        true
    );

    wp_localize_script('gridbase-admin-js', 'gridbaseAdmin', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('gridbase_admin_nonce'),
        'apiKey' => get_option('gridbase_api_key'),
        'logoUrl' => get_option('gridbase_partner_logo')
    ));
}
add_action('admin_enqueue_scripts', 'gridbase_enqueue_admin_assets');