<?php

function seller_net_sheet_submit() {
    
    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', 401); 
    }

    $desired_shortcode = 'gridbase_seller_net_sheet'; 

    $integrations = get_option('gridbase_user_integrations');

    $integrationId = null;
    foreach ($integrations as $integration) {
        if ($integration['shortCode'] === $desired_shortcode) {
            $integrationId = $integration['id'];
            break;
        }
    }

    if (!$integrationId) {
        wp_die('Unable to resolve the Integration ID for the provided shortcode.', 500);
    }

    $endpoint_url = GRIDBASE_API_ENDPOINT . "/v1/orders/seller-net-sheet/submit";  
    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);
    $data['integrationId'] = $integrationId;


    $args = array(
        'method'      => 'POST',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'body'        => json_encode($data),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_post($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        wp_send_json_success(wp_remote_retrieve_body($response));
    }

    wp_die(); 
}

add_action('wp_ajax_seller_net_sheet_submit_action', 'seller_net_sheet_submit');
add_action('wp_ajax_nopriv_seller_net_sheet_submit_action', 'seller_net_sheet_submit');

function seller_net_sheet_address_lookup() {
    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $address = isset($_GET['address']) ? $_GET['address'] : '';
    if(empty($address)) {
        wp_die('Address parameter is missing.', "400");
    }

    $endpoint_url =  GRIDBASE_API_ENDPOINT . "/v1/orders/seller-net-sheet/address/" . urlencode($address);

    $args = array(
        'method'      => 'GET',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_get($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        wp_send_json_success(wp_remote_retrieve_body($response));
    }
}
add_action('wp_ajax_seller_net_sheet_address_lookup_action', 'seller_net_sheet_address_lookup');
add_action('wp_ajax_nopriv_seller_net_sheet_address_lookup_action', 'seller_net_sheet_address_lookup');

function get_user_settings() {

    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $desired_shortcode = 'gridbase_seller_net_sheet'; 

    $integrations = get_option('gridbase_user_integrations');

    $integrationId = null;
    foreach ($integrations as $integration) {
        if ($integration['shortCode'] === $desired_shortcode) {
            $integrationId = $integration['id'];
            break;
        }
    }

    if (!$integrationId) {
        wp_die('Unable to resolve the Integration ID for the provided shortcode.', 500);
    }

    $endpoint_url =  GRIDBASE_API_ENDPOINT . "/v1/orders/seller-net-sheet/settings/integration/" . urlencode($integrationId);

    $args = array(
        'method'      => 'GET',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_get($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        wp_send_json_success(wp_remote_retrieve_body($response));
    }
}
add_action('wp_ajax_get_user_settings_action', 'get_user_settings');
add_action('wp_ajax_nopriv_get_user_settings_action', 'get_user_settings');

