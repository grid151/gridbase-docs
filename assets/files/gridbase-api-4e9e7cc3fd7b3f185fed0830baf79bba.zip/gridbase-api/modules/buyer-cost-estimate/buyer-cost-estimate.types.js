class BuyerCostData {
  constructor() {
    this.gridBaseOrderId = null;
    this.buyerName = "";
    this.name = "";
    this.email = "";
    this.salesPrice = 0;
    this.address = {
      street: "",
      cityDesc: "",
      stateId: "",
      countyDesc: "",
      zip: "",
    };
    this.downPayment = 0;
    this.loanAmount = 0;
    this.interestRate = 0;
    this.loanTerm = 360;
    this.pmi = 0;
    this.hoaFees = 0;
    this.homeownersInsurance = 0;
    this.agentFees = 0;
    this.agentFeesType = "Dollar";
    this.closingDate = "";
    this.lenderCredits = 0;
    this.loanType = "conventional";
    this.reportId = null;

    // New Fields
    this.propertyTaxes = 0;
    this.titleInsurancePremium = 0;
    this.titleAndEscrowFees = 0;
    this.recordingFees = 0;
    this.transferTaxes = 0;
    this.appraisalFee = 0;
    this.inspectionFee = 0;
    this.additionalCosts = 0;
  }
}
