var app = new Vue({
  el: "#buyer_cost_estimate",
  data() {
    return {
      form: new BuyerCostData(),
      suggestions: [],
      debounceTimeout: null,
      isSubmitted: false,
      isLoading: false,
      isLoadingAddress: false,
      isModalVisible: false,
      debouncedMonthlyPayment: 0.0,
      logoUrl:
        "https://gridbase.io/wp-content/themes/gridbase/assets/img/logo-registered.svg",
      settings: {
        hasMelissaData: false,
        integrationId: null,
        reportId: null,
      },
      errors: [],
      estimatedMonthlyPayment: 0.0,
    };
  },
  computed: {
    CalculateMonthlyPayment() {
      const loanAmount = Number(this.form.loanAmount) || 0;
      const annualInterestRate = (Number(this.form.interestRate) || 0) / 100;
      const monthlyInterestRate = annualInterestRate / 12;
      const loanTerm = Number(this.form.loanTerm) || 0;

      let monthlyPayment = 0; // Initialize monthly payment
      if (monthlyInterestRate > 0 && loanTerm > 0) {
        const ratePower = Math.pow(1 + monthlyInterestRate, loanTerm);
        const denominator = ratePower - 1;
        if (denominator > 0) {
          monthlyPayment =
            (loanAmount * monthlyInterestRate * ratePower) / denominator;
        }
      }

      const monthlyHomeownersInsurance = Number(
        (Number(this.form.homeownersInsurance) || 0) / 12
      );
      const monthlyPropertyTaxes = Number(
        (Number(this.form.propertyTaxes) || 0) / 12
      );

      const pmi = Number(this.form.pmi) || 0;
      const hoaFees = Number(this.form.hoaFees) || 0;

      const totalPayment =
        monthlyPayment +
        pmi +
        hoaFees +
        monthlyHomeownersInsurance +
        monthlyPropertyTaxes;

      return totalPayment;
    },
  },

  created() {
    var appContainer = document.getElementById("buyer_cost_estimate");
    if (appContainer) {
      appContainer.style.visibility = "visible";
    }
    const loader = document.getElementById("grid-loader-bce");
    if (loader) {
      loader.style.visibility = "visible";
    }
    const confirmation = document.getElementById("grid-confirmation-bce");
    if (confirmation) {
      confirmation.style.visibility = "visible";
    }

    const errors = document.getElementById("grid-errors-bce");
    if (errors) {
      errors.style.visibility = "visible";
    }
    this.GetSettings();
    this.GetPartnerLogo();
  },
  methods: {
    GetPartnerLogo() {
      fetch(my_ajax_object.ajax_url + "?action=get_partner_logo_action", {
        method: "POST",
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success && data.data.logoUrl) {
            this.logoUrl = data.data.logoUrl; // Set the logo URL dynamically
          }
        })
        .catch((error) => {
          console.error("Error fetching logo:", error);
        });
    },
    Submit() {
      this.errors = [];

      if (!this.form.buyerName) {
        this.errors.push("Buyer Name is required.");
      }
      if (!this.form.salesPrice) {
        this.errors.push("Sales Price is required.");
      }
      if (!this.form.loanAmount) {
        this.errors.push("Loan Amount is required.");
      }
      if (!this.form.interestRate) {
        this.errors.push("Interest Rate is required.");
      }
      if (!this.form.loanTerm) {
        this.errors.push("Loan Term is required.");
      }
      if (!this.form.address.street) {
        this.errors.push("Street Address is required.");
      }
      if (!this.form.address.cityDesc) {
        this.errors.push("City is required.");
      }
      if (!this.form.address.stateId) {
        this.errors.push("State is required.");
      }
      if (!this.form.address.zip) {
        this.errors.push("Zip is required.");
      }
      if (!this.form.closingDate) {
        this.errors.push("Closing date is required.");
      }

      if (!this.errors.length) {
        this.isLoading = true;
        fetch(
          my_ajax_object.ajax_url + "?action=buyer_cost_estimate_submit_action",
          {
            method: "POST",
            body: JSON.stringify(this._data.form),
            headers: {
              "Content-Type": "application/json",
            },
          }
        )
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              var results = JSON.parse(data.data);
              this._data.form.gridBaseOrderId = results.gridBaseOrderId;
              this.isModalVisible = true; // Show success modal
              this.GetReport();
            } else {
              this.errors.push(data.message || "Submission failed."); // Handle API error
            }
          })
          .catch((error) => {
            console.error("Error:", error);
            this.errors.push("An error occurred while submitting the form.");
          })
          .finally(() => {
            this.isLoading = false;
          });
      }
    },
    closeModal() {
      this.isModalVisible = false; // Close the modal
    },
    GetReport() {
      this.isLoading = true;
      const reportRequest = {
        orderId: this._data.form.gridBaseOrderId,
        reportId: this._data.settings.reportId,
        reportFormat: "Pdf",
      };
      fetch(my_ajax_object.ajax_url + "?action=get_report_action", {
        method: "POST",
        body: JSON.stringify(reportRequest),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            window.open(data.data.url);
          } else {
            this.errors.push(data.message || "Failed to fetch the report.");
          }
        })
        .catch((error) => {
          console.error("Error:", error);
          this.errors.push("An error occurred while fetching the report.");
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
    AddressLookupDebounced(value) {
      if (this._data.settings.hasMelissaData == false) return;
      clearTimeout(this.debounceTimeout);
      this.isLoadingAddress = true;
      this.debounceTimeout = setTimeout(() => {
        this.AddressLookup(value);
      }, 300);
    },
    AddressLookup(value) {
      this.isLoadingAddress = true;
      fetch(
        `${
          my_ajax_object.ajax_url
        }?action=seller_net_sheet_address_lookup_action&address=${encodeURIComponent(
          value
        )}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
        .then((response) => response.json())
        .then((data) => {
          this.isLoadingAddress = false;

          const globalExpressEntryResponse = JSON.parse(data.data);
          if (
            globalExpressEntryResponse &&
            globalExpressEntryResponse.results &&
            globalExpressEntryResponse.results.length > 0
          ) {
            this.suggestions = globalExpressEntryResponse.results;
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoadingAddress = false;
        });
    },
    SelectAddressSuggestion(suggestion) {
      this.form.address.fullAddress = suggestion.address.address;
      this.form.address.street = suggestion.address.address1;
      this.form.address.cityDesc = suggestion.address.locality;
      this.form.address.stateId = suggestion.address.administrativeArea;
      this.form.address.countyDesc = suggestion.address.subAdministrativeArea;
      this.form.address.zip = suggestion.address.postalCodePrimary;
      this.suggestions = [];
    },
    FormatCurrency(
      value,
      salesPrice = null,
      type = null,
      locale = "en-US",
      currency = "USD"
    ) {
      if (type == "Percentage") {
        return (
          "$" +
          new Intl.NumberFormat(locale, {
            style: "decimal",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format((value = salesPrice * (value / 100)))
        );
      } else {
        return (
          "$" +
          new Intl.NumberFormat(locale, {
            style: "decimal",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format(value)
        );
      }
    },
    FormatDate(date) {
      if (!(date instanceof Date)) {
        date = new Date(date);
      }

      let day = date.getDate().toString();
      let month = (date.getMonth() + 1).toString();
      let year = date.getFullYear();
      if (day.length < 2) day = "0" + day;
      if (month.length < 2) month = "0" + month;

      return `${month}/${day}/${year}`;
    },
    ClearForm() {
      this.form = new BuyerCostData();
      this.errors = [];
      this.suggestions = [];
      this.isSubmitted = false;
    },

    GetSettings() {
      this.isLoading = false;
      fetch(
        my_ajax_object.ajax_url + "?action=buyer_cost_estimate_settings_action",
        {
          method: "POST",
          body: JSON.stringify(this._data.form),
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
        .then((response) => response.json())
        .then((data) => {
          var results = JSON.parse(data.data);
          this._data.settings = results;
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
    // debounceCalculation(payment) {
    //   if (this.debounceTimeout) {
    //     clearTimeout(this.debounceTimeout);
    //   }

    //   // Set a new timeout to update the debounced result after a delay
    //   this.debounceTimeout = setTimeout(() => {
    //     this.debouncedMonthlyPayment = payment;
    //   }, 300); // Adjust the delay as needed (e.g., 300ms)
    // },
  },
});
