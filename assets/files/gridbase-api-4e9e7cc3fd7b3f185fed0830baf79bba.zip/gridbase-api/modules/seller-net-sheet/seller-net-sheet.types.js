class Calculator_Data {
  constructor() {
    this.id = null;
    this.integrationId = null;
    this.organizationId = null;
    this.gridBaseOrderId = null;
    this.loanAmount = 0.0;
    this.salesPrice = 0;
    this.salesPrice2 = null;
    this.salesPrice3 = null;
    this.propertyOwner = "";
    this.address = {
      fullAddress: "",
      cityDesc: "",
      countyDesc: "",
      stateId: "",
      street: "",
      streetLine2: "",
      zip: "",
    };
    this.mortgagePayoff = 0;
    this.agentFees = 5;
    this.sellerConcessions = 2;
    this.estateTaxes = 6;
    this.prepRepairCosts = 0;
    this.titleInsurancePremium = 0;
    this.titleAndEscrowFees = 0;
    this.recordingFees = 0;
    this.recordingTransferFees = 0;
    //this.sellerClosingCosts = 2;
    this.otherSellerCosts = 0;
    this.name = "";
    this.email = "";
    this.proceeds = 0;
    this.currentDate = null;
    this.titleAndEscrowFeesType = "Dollar";
    this.agentFeesType = "Percentage";
    this.sellerConcessionsType = "Dollar";
    this.estateTaxesType = "Percentage";
    //this.sellerClosingCostsType = "Percentage";
    this.otherSellerCostsDescription = null;
    this.transferTaxes = 0;
    this.createdDate = new Date();
    this.reportId = null;
    this.closingDate = "";
    this.taxProration = 0;
    this.taxProrationEndDate = "";
  }
}
