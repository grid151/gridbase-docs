var app = new Vue({
  el: "#seller_netsheet",
  data() {
    return {
      form: new Calculator_Data(),
      suggestions: [],
      debounceTimeout: null,
      isSubmitted: false,
      isLoading: false,
      isLoadingAddress: false,
      isModalVisible: false,
      logoUrl:
        "https://gridbase.io/wp-content/themes/gridbase/assets/img/logo-registered.svg",
      settings: {
        hasMelissaData: false,
        integrationId: null,
        reportId: null,
      },
      results: null,
      errors: [],
    };
  },
  created() {
    var appContainer = document.getElementById("seller_netsheet");
    if (appContainer) {
      appContainer.style.visibility = "visible";
    }

    const loader = document.getElementById("grid-loader");
    if (loader) {
      loader.style.visibility = "visible";
    }
    const confirmation = document.getElementById("grid-confirmation");
    if (confirmation) {
      confirmation.style.visibility = "visible";
    }

    const errors = document.getElementById("grid-errors");
    if (errors) {
      errors.style.visibility = "visible";
    }
    this.GetSettings();
    this.GetPartnerLogo();
  },
  methods: {
    GetPartnerLogo() {
      fetch(my_ajax_object.ajax_url + "?action=get_partner_logo_action", {
        method: "POST",
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success && data.data.logoUrl) {
            this.logoUrl = data.data.logoUrl; // Set the logo URL dynamically
          }
        })
        .catch((error) => {
          console.error("Error fetching logo:", error);
        });
    },
    Submit() {
      this.errors = []; // Reset errors array

      if (!this.form.name) {
        this.errors.push("Full Name is required.");
      }
      if (!this.form.email) {
        this.errors.push("Email is required.");
      }
      if (!this.form.propertyOwner) {
        this.errors.push("Owner is required.");
      }
      if (!this.form.address.street) {
        this.errors.push("Property Address is required.");
      }
      if (!this.form.address.cityDesc) {
        this.errors.push("City is required.");
      }
      if (!this.form.address.stateId) {
        this.errors.push("State is required.");
      }
      if (!this.form.address.countyDesc) {
        this.errors.push("County is required.");
      }
      if (!this.form.address.zip) {
        this.errors.push("Zip is required.");
      }
      if (!this.form.closingDate) {
        this.errors.push("Estimated Closing Date is required.");
      }
      if (!this.form.taxProrationEndDate) {
        this.errors.push("Tax Proration End Date is required.");
      }

      if (!this.errors.length) {
        this.isLoading = true;
        fetch(
          my_ajax_object.ajax_url + "?action=seller_net_sheet_submit_action",
          {
            method: "POST",
            body: JSON.stringify(this._data.form),
            headers: {
              "Content-Type": "application/json",
            },
          }
        )
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            var results = JSON.parse(data.data);
            this._data.form.gridBaseOrderId = results.gridBaseOrderId;
            this.isModalVisible = true;
            this.GetReport();
            //this._data.isSubmitted = true;
          })
          .catch((error) => {
            console.error("Error:", error);
          })
          .finally(() => {
            this.isLoading = false;
          });
      }
    },
    GetSettings() {
      this.isLoading = false;
      fetch(my_ajax_object.ajax_url + "?action=get_user_settings_action", {
        method: "POST",
        body: JSON.stringify(this._data.form),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          var results = JSON.parse(data.data);
          this._data.settings = results;
          console.log(this._data.settings);
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
    AddressLookupDebounced(value) {
      if (this._data.settings.hasMelissaData == false) return;
      clearTimeout(this.debounceTimeout);
      this.isLoadingAddress = true;
      this.debounceTimeout = setTimeout(() => {
        this.AddressLookup(value);
      }, 300);
    },
    AddressLookup(value) {
      this.isLoadingAddress = true;
      fetch(
        `${
          my_ajax_object.ajax_url
        }?action=seller_net_sheet_address_lookup_action&address=${encodeURIComponent(
          value
        )}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
        .then((response) => response.json())
        .then((data) => {
          this.isLoadingAddress = false;

          const globalExpressEntryResponse = JSON.parse(data.data);
          if (
            globalExpressEntryResponse &&
            globalExpressEntryResponse.results &&
            globalExpressEntryResponse.results.length > 0
          ) {
            this.suggestions = globalExpressEntryResponse.results;
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoadingAddress = false;
        });
    },
    SelectAddressSuggestion(suggestion) {
      this.form.address.fullAddress = suggestion.address.address;
      this.form.address.street = suggestion.address.address1;
      this.form.address.cityDesc = suggestion.address.locality;
      this.form.address.stateId = suggestion.address.administrativeArea;
      this.form.address.countyDesc = suggestion.address.subAdministrativeArea;
      this.form.address.zip = suggestion.address.postalCodePrimary;
      // Populate other fields as needed
      this.suggestions = []; // Hide suggestions
    },
    GetReport() {
      this.isLoading = true;
      var report_request = {
        orderId: this._data.form.gridBaseOrderId,
        reportId: this._data.settings.reportId,
        reportFormat: "Pdf",
      };
      fetch(my_ajax_object.ajax_url + "?action=get_report_action", {
        method: "POST",
        body: JSON.stringify(report_request),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          window.open(data.data.url);
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
    CombineAddressParts(address) {
      return `${address.street}, ${address.cityDesc}, ${address.stateId} ${address.zip}`;
    },
    ClearForm() {
      this._data.form = new Calculator_Data();
    },
    closeModal() {
      this.isModalVisible = false; // Close the modal
    },
    FormatCurrency(
      value,
      salesPrice = null,
      type = null,
      locale = "en-US",
      currency = "USD"
    ) {
      if (type == "Percentage") {
        return (
          "$" +
          new Intl.NumberFormat(locale, {
            style: "decimal",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format((value = salesPrice * (value / 100)))
        );
      } else {
        return (
          "$" +
          new Intl.NumberFormat(locale, {
            style: "decimal",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format(value)
        );
      }
    },
    FormatDate(date) {
      if (!(date instanceof Date)) {
        date = new Date(date);
      }

      let day = date.getDate().toString();
      let month = (date.getMonth() + 1).toString();
      let year = date.getFullYear();
      if (day.length < 2) day = "0" + day;
      if (month.length < 2) month = "0" + month;

      return `${month}/${day}/${year}`;
    },
    GetDollarPercentage(salesPrice, value, type) {
      return type == "Percentage" ? salesPrice * (value / 100) : value;
    },
    ShowPercentage(type, value) {
      return type === "Percentage" ? value + "%" : "";
    },
  },
});
