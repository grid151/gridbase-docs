<?php

/**
 * Plugin Name: GridBase API Connector
 * Plugin URI: http://gridbase.io/
 * Description: A plugin to connect WordPress with the GridBase API.
 * Version: 1.0
 * Author: GridBase Team
 * Author URI: http://gridbase.io/
 */

define('GRIDBASE_API_ENDPOINT', 'http://localhost:5100');

// Includes
require_once plugin_dir_path(__FILE__) . 'includes/settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/seller-netsheet-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/buyer-cost-estimate-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/common-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcodes.php';

// Hooks
add_action('admin_menu', 'gridbase_api_add_admin_menu');