Vue.component("currency-input", {
  template: `
	  <div>
		<input 
		  ref="currencyInput" 
		  class="form-control"
		  :class="inputClass"
		  :value="formattedValue"
		  @input="updateValue($event.target.value)"
		  @blur="isActive = false"
		  @focus="selectAll" />
	  </div>
	`,
  props: {
    value: {
      type: [Number, String],
      default: 0,
    },
    inputClass: String,
    type: {
      type: String,
      default: "Dollar", // Default type is 'currency'
    },
    symbols: {
      type: Boolean,
      default: true, // Decide whether to show symbols by default
    },
  },
  data() {
    return {
      isActive: false,
      internalValue: "", // Store the internal representation of the input value
    };
  },
  watch: {
    // Watch for changes in value prop to update internalValue accordingly
    value: {
      immediate: true,
      handler(newValue) {
        this.internalValue = newValue.toString();
      },
    },
    // Reactively handle changes in type to reformat the value if necessary
    type(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.formatValueBasedOnType();
      }
    },
  },
  computed: {
    formattedValue() {
      // Display the value based on the active state and format if necessary
      if (!this.isActive && this.type === "Dollar" && this.symbols) {
        return `$${this.formatAsCurrency(this.internalValue)}`;
      } else if (!this.isActive && this.type === "Percentage" && this.symbols) {
        return `${this.internalValue}%`;
      }
      return this.internalValue;
    },
  },
  methods: {
    formatAsCurrency(value) {
      const numericValue = Number(value);
      if (isNaN(numericValue)) return "0.00";
      return numericValue.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },
    updateValue(inputValue) {
      // Process input value and emit to parent
      this.internalValue = inputValue;
      this.$emit(
        "input",
        this.type === "currency" ? parseFloat(inputValue) : inputValue
      );
    },
    selectAll() {
      this.isActive = true;
      this.$nextTick(() => {
        this.$refs.currencyInput.select();
      });
    },
    formatValueBasedOnType() {
      // Conditionally format the internal value based on type
      if (this.type === "Dollar") {
        this.internalValue = this.formatAsCurrency(this.value);
      } else if (this.type === "Percentage") {
        // Ensure any necessary formatting or parsing for Percentages is handled here
        this.internalValue = parseFloat(this.value).toString();
      }
      // Ensure the displayed value is updated appropriately
      this.$emit("input", this.internalValue);
    },
  },
});
