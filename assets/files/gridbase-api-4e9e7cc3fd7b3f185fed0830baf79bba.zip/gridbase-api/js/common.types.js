class Address {
  constructor() {
    this.fullAddress = "";
    this.cityDesc = "";
    this.countyDesc = "";
    this.stateId = "";
    this.street = "";
    this.streetLine2 = "";
    this.zip = "";
  }
}

class GlobalExpressEntryResponse {
  constructor(version, resultCode, errorString, results) {
    this.version = version;
    this.resultCode = resultCode;
    this.errorString = errorString;
    this.results = results;
  }
}

class GlobalExpressEntryResult {
  constructor(address) {
    this.address = address;
  }
}

class MelissaAddress {
  constructor(
    address,
    address1,
    address2,
    address3,
    address4,
    address5,
    address6,
    address7,
    address8,
    address9,
    address10,
    address11,
    address12,
    deliveryAddress,
    deliveryAddress1,
    deliveryAddress2,
    deliveryAddress3,
    deliveryAddress4,
    deliveryAddress5,
    deliveryAddress6,
    deliveryAddress7,
    deliveryAddress8,
    deliveryAddress9,
    deliveryAddress10,
    deliveryAddress11,
    deliveryAddress12,
    countryName,
    ISO3166_2,
    ISO3166_3,
    ISO3166_N,
    superAdministrativeArea,
    administrativeArea,
    subAdministrativeArea,
    locality,
    cityAccepted,
    cityNotAccepted,
    dependentLocality,
    doubleDependentLocality,
    thoroughfare,
    dependentThoroughfare,
    building,
    premise,
    subBuilding,
    postalCode,
    postalCodePrimary,
    postalCodeSecondary,
    organization,
    postBox,
    unmatched,
    generalDelivery,
    deliveryInstallation,
    route,
    additionalContent,
    countrySubdivisionCode,
    MAK,
    baseMAK
  ) {
    this.address = address;
    this.address1 = address1;
    this.address2 = address2;
    this.address3 = address3;
    this.address4 = address4;
    this.address5 = address5;
    this.address6 = address6;
    this.address7 = address7;
    this.address8 = address8;
    this.address9 = address9;
    this.address10 = address10;
    this.address11 = address11;
    this.address12 = address12;
    this.deliveryAddress = deliveryAddress;
    this.deliveryAddress1 = deliveryAddress1;
    this.deliveryAddress2 = deliveryAddress2;
    this.deliveryAddress3 = deliveryAddress3;
    this.deliveryAddress4 = deliveryAddress4;
    this.deliveryAddress5 = deliveryAddress5;
    this.deliveryAddress6 = deliveryAddress6;
    this.deliveryAddress7 = deliveryAddress7;
    this.deliveryAddress8 = deliveryAddress8;
    this.deliveryAddress9 = deliveryAddress9;
    this.deliveryAddress10 = deliveryAddress10;
    this.deliveryAddress11 = deliveryAddress11;
    this.deliveryAddress12 = deliveryAddress12;
    this.countryName = countryName;
    this.ISO3166_2 = ISO3166_2;
    this.ISO3166_3 = ISO3166_3;
    this.ISO3166_N = ISO3166_N;
    this.superAdministrativeArea = superAdministrativeArea;
    this.administrativeArea = administrativeArea;
    this.subAdministrativeArea = subAdministrativeArea;
    this.locality = locality;
    this.cityAccepted = cityAccepted;
    this.cityNotAccepted = cityNotAccepted;
    this.dependentLocality = dependentLocality;
    this.doubleDependentLocality = doubleDependentLocality;
    this.thoroughfare = thoroughfare;
    this.dependentThoroughfare = dependentThoroughfare;
    this.building = building;
    this.premise = premise;
    this.subBuilding = subBuilding;
    this.postalCode = postalCode;
    this.postalCodePrimary = postalCodePrimary;
    this.postalCodeSecondary = postalCodeSecondary;
    this.organization = organization;
    this.postBox = postBox;
    this.unmatched = unmatched;
    this.generalDelivery = generalDelivery;
    this.deliveryInstallation = deliveryInstallation;
    this.route = route;
    this.additionalContent = additionalContent;
    this.countrySubdivisionCode = countrySubdivisionCode;
    this.MAK = MAK;
    this.baseMAK = baseMAK;
  }
}
