<?php
/**
 * Plugin Name: GridBase API Connector
 * Plugin URI: http://gridbase.io/
 * Description: A plugin to connect WordPress with the GridBase API.
 * Version: 1.0
 * Author: GridBase Team
 * Author URI: http://gridbase.io/
 */

define('GRIDBASE_API_ENDPOINT', 'https://app.gridbase.io');

function gridbase_api_init_settings() {
    register_setting('gridbase_api_settings', 'gridbase_api_key');
    register_setting('gridbase_api_settings', 'gridbase_integrationId', 'validate_integrationId');
    register_setting('gridbase_api_settings', 'gridbase_organizationId', 'validate_organizationId');
    register_setting('gridbase_api_settings', 'gridbase_partner_logo');

    
    add_settings_section(
        'gridbase_api_settings_section',
        'GridBase API Settings',
        'gridbase_api_settings_section_cb',
        'gridbase_api'
    );
    
    add_settings_field(
        'gridbase_api_key_field',
        'GridBase API Key',
        'gridbase_api_key_field_cb',
        'gridbase_api',
        'gridbase_api_settings_section'
    );
    add_settings_field(
        'gridbase_integrationId_field',
        'GridBase Integration ID',
        'gridbase_integrationId_field_cb',
        'gridbase_api',
        'gridbase_api_settings_section'
    );
    add_settings_field(
        'gridbase_organizationId_field',
        'GridBase Organization ID',
        'gridbase_organizationId_field_cb',
        'gridbase_api',
        'gridbase_api_settings_section'
    );
    add_settings_field(
        'gridbase_partner_logo_field',
        'Partner Logo URL',
        'gridbase_partner_logo_field_cb',
        'gridbase_api',
        'gridbase_api_settings_section'
    );
}

function gridbase_partner_logo_field_cb() {
    $setting = get_option('gridbase_partner_logo');
    echo "<input type='text' name='gridbase_partner_logo' style='min-width:100%;max-width:400px;margin-left: -50px;' value='" . esc_attr($setting) . "' />";
    echo '<p class="description">Enter the URL of your logo or image to be used for the loading icon.</p>';
}

function gridbase_api_settings_section_cb() {
    echo '<p>Enter your GridBase API Key here.</p>';
}

function gridbase_api_key_field_cb() {
    $setting = get_option('gridbase_api_key');
    echo "<input type='text' name='gridbase_api_key' style='min-width:100%;max-width:400px;margin-left: -100px;' value='" . esc_attr($setting) . "' />";
}

function gridbase_integrationId_field_cb() {
    $setting = get_option('gridbase_integrationId');
    echo "<input type='text' name='gridbase_integrationId' style='min-width:100%;max-width:400px;margin-left: -50px;' value='" . esc_attr($setting) . "' />";
}

function gridbase_organizationId_field_cb() {
    $setting = get_option('gridbase_organizationId');
    echo "<input type='text' name='gridbase_organizationId' style='min-width:100%;max-width:400px;margin-left: -50px;' value='" . esc_attr($setting) . "' />";
}

function gridbase_api_add_admin_menu() {
    add_menu_page(
        'GridBase API Settings',
        'GridBase API',
        'manage_options',
        'gridbase_api',
        'gridbase_api_settings_page'
    );
}

function gridbase_enqueue_admin_styles($hook) {
    if ('toplevel_page_gridbase_api' !== $hook) {
        return;
    }

    wp_enqueue_style(
        'gridbase-api-settings-style',
        plugin_dir_url(__FILE__) . 'gridbase-api-settings.css'
    );
}

function gridbase_api_settings_page() {
    ?>
        <div class="gridbase-container">
            <!-- Form Column -->
            <div class="gridbase-form-column">
            <?php settings_errors(); ?> <!-- This line displays settings errors -->
                <form action="options.php" method="post">
                    <?php
                    settings_fields('gridbase_api_settings');
                    do_settings_sections('gridbase_api');
                    submit_button();
                    ?>
                </form>
            </div>

            <!-- Documentation Column -->
            <div class="gridbase-docs-column">            
                <!-- Seller Net Sheet Section -->
                <div class="gridbase-section">
                    <h2>Seller Net Sheet</h2>
                    <p>Use this shortcode to display the Seller Net Sheet calculator.</p>
                    <p><code>[gridbase_seller_netsheet]</code></p>
                    <img src="<?php echo plugin_dir_url(__FILE__) . 'SellerNetSheet.png'; ?>" alt="Seller Net Sheet"/>
                </div>
            </div>
        </div>
    <?php
}

function validate_integrationId($option) {
   if (preg_match('/^[0-9a-fA-F]{24}$/', $option)) {
    return $option; 
} else {

    add_settings_error(
        'gridbase_integrationId',
        'gridbase_integrationId_error', 
       // 'The Organization ID is not in a valid format. It should be a 24-character hexadecimal string.',
        'The Integration ID is not in a valid format.',
        'error' 
    );
    return get_option('gridbase_integrationId');
}
}

function validate_organizationId($option) {
    if (preg_match('/^[0-9a-fA-F]{24}$/', $option)) {
        return $option;
    } else {
        add_settings_error(
            'gridbase_organizationId',
            'gridbase_organizationId_error',
            'The Organization ID is not in a valid format.',
            'error'
        );
        return get_option('gridbase_organizationId');
    }
}

function seller_net_sheet_short_code() {
    wp_enqueue_script('vue', 'https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js', array(), null, true);
    wp_enqueue_style('vuetify-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), null);
    wp_enqueue_script('boostrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js', array('bs'), null, true);
    wp_enqueue_script('proceeds-calculator-js', plugin_dir_url(__FILE__) . 'proceeds-calculator.js', array('jquery'), null, true);
    wp_localize_script('proceeds-calculator-js', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    wp_enqueue_style('proceeds-calculator-css', plugin_dir_url(__FILE__) . 'proceeds-calculator.css', array(), null);
    ob_start(); 
    $template_path = plugin_dir_path(__FILE__) . 'proceeds-calculator.html';
    $template_content = file_get_contents($template_path);
    $template_content = str_replace('{admin_ajax_url}', esc_url(admin_url('admin-ajax.php')), $template_content);
    echo $template_content;
    return ob_get_clean(); 
}

function seller_net_sheet_submit() {
    
    $organizationId = get_option('gridbase_organizationId');
    if (!$organizationId) {
        wp_die('Please configure your Organization ID first.', "401");
    }

    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $integrationId = get_option('gridbase_integrationId');
    if (!$integrationId) {
        wp_die('Please configure your Integration ID first.', "401"); 
    }

    $endpoint_url =  GRIDBASE_API_ENDPOINT . "/v1/orders/seller-net-sheet/submit";  
    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);
    $data['integrationId'] = $integrationId;
    $data['organizationId'] = $organizationId;
    $args = array(
        'method'      => 'POST',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'body'        => json_encode($data),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );


    $response = wp_remote_post($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        wp_send_json_success(wp_remote_retrieve_body($response));
    }

    wp_die(); 
}

function address_lookup() {
    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $address = isset($_GET['address']) ? $_GET['address'] : '';
    if(empty($address)) {
        wp_die('Address parameter is missing.', "400");
    }

    $endpoint_url =  GRIDBASE_API_ENDPOINT . "/v1/orders/seller-net-sheet/address/" . urlencode($address);

    $args = array(
        'method'      => 'GET',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_get($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        wp_send_json_success(wp_remote_retrieve_body($response));
    }
}

function get_user_settings() {

    $organizationId = get_option('gridbase_organizationId');
    if (!$organizationId) {
        wp_die('Please configure your Organization ID first.', "401");
    }

    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $endpoint_url =  GRIDBASE_API_ENDPOINT . "/v1/orders/seller-net-sheet/settings/" . urlencode($organizationId);

    $args = array(
        'method'      => 'GET',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_get($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        wp_send_json_success(wp_remote_retrieve_body($response));
    }
}

function get_report() {
    $api_key = get_option('gridbase_api_key'); 
    if (!$api_key) {
        wp_die('Please configure your API key first.', "401"); 
    }

    $endpoint_url = GRIDBASE_API_ENDPOINT . "/v1/core/reports/generate";
    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true);

    $args = array(
        'method'      => 'POST',
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-GridBase-ApiKey' => $api_key,
        ),
        'body'        => json_encode($data),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false,
        'data_format' => 'body',
    );

    $response = wp_remote_post($endpoint_url, $args);

    if (is_wp_error($response)) {
        wp_send_json_error($response->get_error_message());
    } else {
        $body = wp_remote_retrieve_body($response);
        // Send the URL as a plain string response
        wp_send_json_success(array('url' => $body));
    }

    wp_die();
}

function get_partner_logo() {
    $logo_url = get_option('gridbase_partner_logo');
    wp_send_json_success(array('logoUrl' => esc_url($logo_url)));
}


add_action('wp_ajax_get_partner_logo_action', 'get_partner_logo');
add_action('wp_ajax_nopriv_get_partner_logo_action', 'get_partner_logo');

add_action('admin_enqueue_scripts', 'gridbase_enqueue_admin_styles');
add_action('wp_ajax_seller_net_sheet_save_action', 'seller_net_sheet_save');
add_action('wp_ajax_nopriv_seller_net_sheet_save_action', 'seller_net_sheet_save');
add_action('wp_ajax_seller_net_sheet_submit_action', 'seller_net_sheet_submit');
add_action('wp_ajax_nopriv_seller_net_sheet_submit_action', 'seller_net_sheet_submit');

add_action('wp_ajax_address_lookup_action', 'address_lookup');
add_action('wp_ajax_nopriv_address_lookup_action', 'address_lookup');

add_action('wp_ajax_get_user_settings_action', 'get_user_settings');
add_action('wp_ajax_nopriv_get_user_settings_action', 'get_user_settings');


add_action('wp_ajax_get_report_action', 'get_report');
add_action('wp_ajax_nopriv_get_report_action', 'get_report');

add_action('admin_init', 'gridbase_api_init_settings');
add_action('admin_menu', 'gridbase_api_add_admin_menu');
add_shortcode('gridbase_seller_netsheet', 'seller_net_sheet_short_code');





