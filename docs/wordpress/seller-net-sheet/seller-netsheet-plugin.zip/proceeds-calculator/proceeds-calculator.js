let debounceTimeout = null;

class Semaphore {
  constructor(max) {
    this.max = max;
    this.counter = 0;
    this.waiting = [];
  }

  async acquire() {
    if (this.counter < this.max) {
      this.counter++;
      return Promise.resolve(true);
    }

    // Wait for a signal to proceed
    return new Promise((resolve) => {
      this.waiting.push(resolve);
    });
  }

  release() {
    this.counter--;

    if (this.waiting.length > 0) {
      this.counter++;
      const next = this.waiting.shift();
      next(true);
    }
  }
}

class Calculator_Data {
  constructor() {
    this.id = null;
    this.integrationId = null;
    this.organizationId = null;
    this.gridBaseOrderId = null;
    this.loanAmount = 0.0;
    this.salesPrice = 0;
    this.salesPrice2 = null;
    this.salesPrice3 = null;
    this.propertyOwner = "";
    this.address = {
      fullAddress: "",
      cityDesc: "",
      countyDesc: "",
      stateId: "",
      street: "",
      streetLine2: "",
      zip: "",
    };
    this.mortgagePayoff = 0;
    this.agentFees = 5;
    this.sellerConcessions = 2;
    this.estateTaxes = 6;
    this.prepRepairCosts = 0;
    this.titleInsurancePremium = 0;
    this.titleAndEscrowFees = 0;
    this.recordingFees = 0;
    this.recordingTransferFees = 0;
    //this.sellerClosingCosts = 2;
    this.otherSellerCosts = 0;
    this.name = "";
    this.email = "";
    this.proceeds = 0;
    this.currentDate = null;
    this.titleAndEscrowFeesType = "Dollar";
    this.agentFeesType = "Percentage";
    this.sellerConcessionsType = "Dollar";
    this.estateTaxesType = "Dollar";
    //this.sellerClosingCostsType = "Percentage";
    this.otherSellerCostsDescription = null;
    this.transferTaxes = 0;
    this.createdDate = new Date();
    this.reportId = null;
    this.closingDate = "";
    this.taxProration = 0;
    this.taxProrationEndDate = "";
  }
}

class Address {
  constructor() {
    this.fullAddress = "";
    this.cityDesc = "";
    this.countyDesc = "";
    this.stateId = "";
    this.street = "";
    this.streetLine2 = "";
    this.zip = "";
  }
}

class GlobalExpressEntryResponse {
  constructor(version, resultCode, errorString, results) {
    this.version = version;
    this.resultCode = resultCode;
    this.errorString = errorString;
    this.results = results;
  }
}

class GlobalExpressEntryResult {
  constructor(address) {
    this.address = address;
  }
}

class MelissaAddress {
  constructor(
    address,
    address1,
    address2,
    address3,
    address4,
    address5,
    address6,
    address7,
    address8,
    address9,
    address10,
    address11,
    address12,
    deliveryAddress,
    deliveryAddress1,
    deliveryAddress2,
    deliveryAddress3,
    deliveryAddress4,
    deliveryAddress5,
    deliveryAddress6,
    deliveryAddress7,
    deliveryAddress8,
    deliveryAddress9,
    deliveryAddress10,
    deliveryAddress11,
    deliveryAddress12,
    countryName,
    ISO3166_2,
    ISO3166_3,
    ISO3166_N,
    superAdministrativeArea,
    administrativeArea,
    subAdministrativeArea,
    locality,
    cityAccepted,
    cityNotAccepted,
    dependentLocality,
    doubleDependentLocality,
    thoroughfare,
    dependentThoroughfare,
    building,
    premise,
    subBuilding,
    postalCode,
    postalCodePrimary,
    postalCodeSecondary,
    organization,
    postBox,
    unmatched,
    generalDelivery,
    deliveryInstallation,
    route,
    additionalContent,
    countrySubdivisionCode,
    MAK,
    baseMAK
  ) {
    this.address = address;
    this.address1 = address1;
    this.address2 = address2;
    this.address3 = address3;
    this.address4 = address4;
    this.address5 = address5;
    this.address6 = address6;
    this.address7 = address7;
    this.address8 = address8;
    this.address9 = address9;
    this.address10 = address10;
    this.address11 = address11;
    this.address12 = address12;
    this.deliveryAddress = deliveryAddress;
    this.deliveryAddress1 = deliveryAddress1;
    this.deliveryAddress2 = deliveryAddress2;
    this.deliveryAddress3 = deliveryAddress3;
    this.deliveryAddress4 = deliveryAddress4;
    this.deliveryAddress5 = deliveryAddress5;
    this.deliveryAddress6 = deliveryAddress6;
    this.deliveryAddress7 = deliveryAddress7;
    this.deliveryAddress8 = deliveryAddress8;
    this.deliveryAddress9 = deliveryAddress9;
    this.deliveryAddress10 = deliveryAddress10;
    this.deliveryAddress11 = deliveryAddress11;
    this.deliveryAddress12 = deliveryAddress12;
    this.countryName = countryName;
    this.ISO3166_2 = ISO3166_2;
    this.ISO3166_3 = ISO3166_3;
    this.ISO3166_N = ISO3166_N;
    this.superAdministrativeArea = superAdministrativeArea;
    this.administrativeArea = administrativeArea;
    this.subAdministrativeArea = subAdministrativeArea;
    this.locality = locality;
    this.cityAccepted = cityAccepted;
    this.cityNotAccepted = cityNotAccepted;
    this.dependentLocality = dependentLocality;
    this.doubleDependentLocality = doubleDependentLocality;
    this.thoroughfare = thoroughfare;
    this.dependentThoroughfare = dependentThoroughfare;
    this.building = building;
    this.premise = premise;
    this.subBuilding = subBuilding;
    this.postalCode = postalCode;
    this.postalCodePrimary = postalCodePrimary;
    this.postalCodeSecondary = postalCodeSecondary;
    this.organization = organization;
    this.postBox = postBox;
    this.unmatched = unmatched;
    this.generalDelivery = generalDelivery;
    this.deliveryInstallation = deliveryInstallation;
    this.route = route;
    this.additionalContent = additionalContent;
    this.countrySubdivisionCode = countrySubdivisionCode;
    this.MAK = MAK;
    this.baseMAK = baseMAK;
  }
}

class SellerNetSheet {
  constructor() {
    this.id = null;
    this.name = null;
    this.address = new Address();
    this.email = null;
    this.salesPrice = null;
    this.salesPrice2 = null;
    this.salesPrice3 = null;
    this.createdDate = new Date();
  }
}

const semaphore = new Semaphore(1);

function formatAsCurrency(value, dec = 2) {
  return Number(value)
    .toFixed(dec)
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "1,");
}
Vue.component("currency-input", {
  template: `
	  <div>
		<input 
		  ref="currencyInput" 
		  class="form-control"
		  :class="inputClass"
		  :value="formattedValue"
		  @input="updateValue($event.target.value)"
		  @blur="isActive = false"
		  @focus="selectAll" />
	  </div>
	`,
  props: {
    value: {
      type: [Number, String],
      default: 0,
    },
    inputClass: String,
    type: {
      type: String,
      default: "Dollar", // Default type is 'currency'
    },
    symbols: {
      type: Boolean,
      default: true, // Decide whether to show symbols by default
    },
  },
  data() {
    return {
      isActive: false,
      internalValue: "", // Store the internal representation of the input value
    };
  },
  watch: {
    // Watch for changes in value prop to update internalValue accordingly
    value: {
      immediate: true,
      handler(newValue) {
        this.internalValue = newValue.toString();
      },
    },
    // Reactively handle changes in type to reformat the value if necessary
    type(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.formatValueBasedOnType();
      }
    },
  },
  computed: {
    formattedValue() {
      // Display the value based on the active state and format if necessary
      if (!this.isActive && this.type === "Dollar" && this.symbols) {
        return `$${this.formatAsCurrency(this.internalValue)}`;
      } else if (!this.isActive && this.type === "Percentage" && this.symbols) {
        return `${this.internalValue}%`;
      }
      return this.internalValue;
    },
  },
  methods: {
    formatAsCurrency(value) {
      const numericValue = Number(value);
      if (isNaN(numericValue)) return "0.00";
      return numericValue.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },
    updateValue(inputValue) {
      // Process input value and emit to parent
      this.internalValue = inputValue;
      this.$emit(
        "input",
        this.type === "currency" ? parseFloat(inputValue) : inputValue
      );
    },
    selectAll() {
      this.isActive = true;
      this.$nextTick(() => {
        this.$refs.currencyInput.select();
      });
    },
    formatValueBasedOnType() {
      // Conditionally format the internal value based on type
      if (this.type === "Dollar") {
        this.internalValue = this.formatAsCurrency(this.value);
      } else if (this.type === "Percentage") {
        // Ensure any necessary formatting or parsing for Percentages is handled here
        this.internalValue = parseFloat(this.value).toString();
      }
      // Ensure the displayed value is updated appropriately
      this.$emit("input", this.internalValue);
    },
  },
});

var app = new Vue({
  el: "#seller_netsheet",
  data() {
    return {
      form: new Calculator_Data(),
      suggestions: [],
      debounceTimeout: null,
      isSubmitted: false,
      isLoading: false,
      isLoadingAddress: false,
      logoUrl:
        "https://gridbase.io/wp-content/themes/gridbase/assets/img/logo-registered.svg",
      settings: {
        hasMelissaData: false,
        integrationId: null,
        reportId: null,
      },
      results: null,
      errors: [],
    };
  },
  created() {
    this.GetSettings();
    this.GetPartnerLogo();
  },
  methods: {
    GetPartnerLogo() {
      fetch(my_ajax_object.ajax_url + "?action=get_partner_logo_action", {
        method: "POST",
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success && data.data.logoUrl) {
            this.logoUrl = data.data.logoUrl; // Set the logo URL dynamically
          }
        })
        .catch((error) => {
          console.error("Error fetching logo:", error);
        });
    },
    Submit() {
      this.errors = []; // Reset errors array

      if (!this.form.name) {
        this.errors.push("Full Name is required.");
      }
      if (!this.form.email) {
        this.errors.push("Email is required.");
      }
      if (!this.form.propertyOwner) {
        this.errors.push("Owner is required.");
      }
      if (!this.form.address.street) {
        this.errors.push("Property Address is required.");
      }
      if (!this.form.address.cityDesc) {
        this.errors.push("City is required.");
      }
      if (!this.form.address.stateId) {
        this.errors.push("State is required.");
      }
      if (!this.form.address.countyDesc) {
        this.errors.push("County is required.");
      }
      if (!this.form.address.zip) {
        this.errors.push("Zip is required.");
      }
      if (!this.form.closingDate) {
        this.errors.push("Estimated Closing Date is required.");
      }
      if (!this.form.taxProrationEndDate) {
        this.errors.push("Tax Proration End Date is required.");
      }

      if (!this.errors.length) {
        this.isLoading = true;
        fetch(
          my_ajax_object.ajax_url + "?action=seller_net_sheet_submit_action",
          {
            method: "POST",
            body: JSON.stringify(this._data.form),
            headers: {
              "Content-Type": "application/json",
            },
          }
        )
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            var results = JSON.parse(data.data);
            this._data.form = results;
            this.GetReport();
            //this._data.isSubmitted = true;
          })
          .catch((error) => {
            console.error("Error:", error);
          })
          .finally(() => {
            this.isLoading = false;
          });
      }
    },
    GetSettings() {
      this.isLoading = false;
      fetch(my_ajax_object.ajax_url + "?action=get_user_settings_action", {
        method: "POST",
        body: JSON.stringify(this._data.form),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          var results = JSON.parse(data.data);
          this._data.settings = results;
          console.log(this._data.settings);
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
    AddressLookupDebounced(value) {
      if (this._data.settings.hasMelissaData == false) return;
      clearTimeout(this.debounceTimeout);
      this.isLoadingAddress = true;
      this.debounceTimeout = setTimeout(() => {
        this.AddressLookup(value);
      }, 300);
    },
    AddressLookup(value) {
      this.isLoadingAddress = true;
      fetch(
        `${
          my_ajax_object.ajax_url
        }?action=address_lookup_action&address=${encodeURIComponent(value)}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
        .then((response) => response.json())
        .then((data) => {
          this.isLoadingAddress = false;

          const globalExpressEntryResponse = JSON.parse(data.data);
          if (
            globalExpressEntryResponse &&
            globalExpressEntryResponse.results &&
            globalExpressEntryResponse.results.length > 0
          ) {
            this.suggestions = globalExpressEntryResponse.results;
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoadingAddress = false;
        });
    },
    SelectAddressSuggestion(suggestion) {
      this.form.address.fullAddress = suggestion.address.address;
      this.form.address.street = suggestion.address.address1;
      this.form.address.cityDesc = suggestion.address.locality;
      this.form.address.stateId = suggestion.address.administrativeArea;
      this.form.address.countyDesc = suggestion.address.subAdministrativeArea;
      this.form.address.zip = suggestion.address.postalCodePrimary;
      // Populate other fields as needed
      this.suggestions = []; // Hide suggestions
    },
    GetReport() {
      this.isLoading = true;
      var report_request = {
        orderId: this._data.form.gridBaseOrderId,
        reportId: this._data.settings.reportId,
        reportFormat: "Pdf",
      };
      fetch(my_ajax_object.ajax_url + "?action=get_report_action", {
        method: "POST",
        body: JSON.stringify(report_request),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          window.open(data.data.url);
        })
        .catch((error) => {
          console.error("Error:", error);
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
    CombineAddressParts(address) {
      return `${address.street}, ${address.cityDesc}, ${address.stateId} ${address.zip}`;
    },
    ClearForm() {
      this._data.form = new Calculator_Data();
    },
    FormatCurrency(
      value,
      salesPrice = null,
      type = null,
      locale = "en-US",
      currency = "USD"
    ) {
      if (type == "Percentage") {
        return (
          "$" +
          new Intl.NumberFormat(locale, {
            style: "decimal",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format((value = salesPrice * (value / 100)))
        );
      } else {
        return (
          "$" +
          new Intl.NumberFormat(locale, {
            style: "decimal",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format(value)
        );
      }
    },
    FormatDate(date) {
      if (!(date instanceof Date)) {
        date = new Date(date);
      }

      let day = date.getDate().toString();
      let month = (date.getMonth() + 1).toString();
      let year = date.getFullYear();
      if (day.length < 2) day = "0" + day;
      if (month.length < 2) month = "0" + month;

      return `${month}/${day}/${year}`;
    },
    GetDollarPercentage(salesPrice, value, type) {
      return type == "Percentage" ? salesPrice * (value / 100) : value;
    },
    ShowPercentage(type, value) {
      return type === "Percentage" ? value + "%" : "";
    },
  },
});
